const host = window.audcore;
const status = document.getElementById("status");
const settings = document.getElementById("settings");

if (!host) {
  status.textContent = "请在声核中打开此皮肤";
  settings.disabled = true;
} else {
  let stop;
  let resolveFirst;
  const firstState = new Promise(resolve => { resolveFirst = resolve; });
  settings.addEventListener("click", () => host.settings.open().catch(error => {
    status.textContent = String(error);
  }));
  try {
    if (host.window.requiresStartup()) host.window.showUnderCover();
    stop = await host.state.subscribe(event => {
      status.textContent = `宿主状态：${event.type}`;
      if (event.type === "snapshot") resolveFirst();
    });
    await firstState;
    await document.fonts.ready;
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    if (host.window.requiresStartup()) host.window.presentFrame();
  } catch (error) {
    status.textContent = String(error);
    host.window.startupFailed();
  }
  window.addEventListener("pagehide", () => stop?.(), { once: true });
}
