﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace AudcoreAsioInstall {
    [StructLayout(LayoutKind.Sequential)] public struct Key {
        public Guid format; public uint id;
        public Key(string guid, uint pid) { format = new Guid(guid); id = pid; }
    }
    [StructLayout(LayoutKind.Explicit, Size = 24)] public struct Value {
        [FieldOffset(0)] public ushort type;
        [FieldOffset(8)] public IntPtr text;
    }
    [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Store {
        void GetCount(out uint count); void GetAt(uint index, out Key key);
        void GetValue(ref Key key, out Value value); void SetValue(ref Key key, ref Value value); void Commit();
    }
    [ComImport, Guid("d666063f-1587-4e43-81f1-b948e807363f"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Device {
        void Activate(ref Guid iid, uint context, IntPtr parameters, out IntPtr result);
        void OpenPropertyStore(uint mode, out Store store);
        void GetId([MarshalAs(UnmanagedType.LPWStr)] out string id); void GetState(out uint state);
    }
    [ComImport, Guid("0bd7a1be-7a1a-44db-8397-cc5392387b5e"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Collection { void GetCount(out uint count); void Item(uint index, out Device device); }
    [ComImport, Guid("a95664d2-9614-4f35-a746-de8db63617e6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Enumerator {
        void EnumAudioEndpoints(int flow, uint mask, out Collection devices);
        void GetDefaultAudioEndpoint(int flow, int role, out Device device);
        void GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out Device device);
    }
    public class Endpoint { public string Id, Owner, Name; public int Flow; public uint State; }
    public class DefaultEndpoint { public string Id; public int Flow, Role; }
    public static class Names {
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int SetDefault(IntPtr self, [MarshalAs(UnmanagedType.LPWStr)] string id, int role);
        public static DefaultEndpoint[] Defaults() {
            Enumerator enumerator=(Enumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("bcde0395-e52f-467c-8e3d-c4579291692e")));
            var result=new List<DefaultEndpoint>();
            try {
                for(int flow=0;flow<2;flow++) for(int role=0;role<3;role++) {
                    string id=null; Device device=null;
                    try { enumerator.GetDefaultAudioEndpoint(flow,role,out device); device.GetId(out id); }
                    catch(COMException error) { if(error.ErrorCode!=unchecked((int)0x80070490)) throw; }
                    finally { if(device!=null) Marshal.ReleaseComObject(device); }
                    result.Add(new DefaultEndpoint {Id=id,Flow=flow,Role=role});
                }
            } finally { Marshal.ReleaseComObject(enumerator); }
            return result.ToArray();
        }
        public static DefaultEndpoint[] DefaultChanges(DefaultEndpoint[] saved, DefaultEndpoint[] current) {
            var result=new List<DefaultEndpoint>();
            foreach(DefaultEndpoint original in saved) {
                DefaultEndpoint actual=Array.Find(current,e=>e.Flow==original.Flow && e.Role==original.Role);
                if(actual==null || !String.Equals(original.Id,actual.Id,StringComparison.OrdinalIgnoreCase)) result.Add(original);
            }
            return result.ToArray();
        }
        public static void RestoreDefaults(DefaultEndpoint[] saved) {
            DefaultEndpoint[] changes=DefaultChanges(saved,Defaults());
            if(changes.Length==0) return; // No writable COM object for unchanged defaults.
            object policyObject=Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("870af99c-171d-4f9e-af0d-e63df40c2bc9")));
            IntPtr unknown=Marshal.GetIUnknownForObject(policyObject),policy=IntPtr.Zero;
            try {
                Guid iid=new Guid("f8679f50-850a-41cf-9c72-430f290290c8"); Marshal.ThrowExceptionForHR(Marshal.QueryInterface(unknown,ref iid,out policy));
                IntPtr table=Marshal.ReadIntPtr(policy);
                SetDefault set=(SetDefault)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(table,13*IntPtr.Size),typeof(SetDefault));
                foreach(DefaultEndpoint entry in changes) {
                    if(String.IsNullOrEmpty(entry.Id)) throw new Exception("There was no default endpoint before installation; cannot restore an empty default via this API");
                    Marshal.ThrowExceptionForHR(set(policy,entry.Id,entry.Role));
                }
            } finally {if(policy!=IntPtr.Zero) Marshal.Release(policy); Marshal.Release(unknown); Marshal.ReleaseComObject(policyObject);}
            if(DefaultChanges(saved,Defaults()).Length!=0) throw new Exception("Default endpoint restoration verification failed");
        }
    }
}
