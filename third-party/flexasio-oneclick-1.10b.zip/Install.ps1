﻿param([switch]$VerifyOnly)
$ErrorActionPreference='Stop'
if([Environment]::Is64BitOperatingSystem -and ![Environment]::Is64BitProcess){
 $extraArgs=if($VerifyOnly){@('-VerifyOnly')}else{@()}
 & "$env:WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath @extraArgs
 exit $LASTEXITCODE
}
try {
 $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $expected=if($manifest.product -eq 'FlexASIO' -and $manifest.version -eq '1.10b'){@('FlexASIO-1.10b.exe')}elseif($manifest.product -eq 'AUR' -and $manifest.version -eq '1.0.0'){@('devcon.exe','SarAsio.dll','SarCtl.exe','synchronousaudiorouter.cat','SynchronousAudioRouter.inf','SynchronousAudioRouter.sys')}else{throw '安装清单的产品或版本无效'}
 if(@($manifest.files).Count -ne $expected.Count -or (@($manifest.files.name|Sort-Object) -join '|') -ne (@($expected|Sort-Object) -join '|')){throw '安装清单的文件列表不完整'}
 foreach($file in $manifest.files){
  if($file.sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw '安装清单的校验值无效'}
  if($file.name -notmatch '^[a-zA-Z0-9_.-]+$'){throw '安装包文件名无效'}
  $path=Join-Path (Join-Path $PSScriptRoot 'payload') $file.name
  if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256){throw "安装资源校验失败：$($file.name)"}
 }
 if($VerifyOnly){Write-Output "$($manifest.product) $($manifest.version)：全部资源校验通过";exit 0}
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 if(!([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'))
  $process=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -Wait -PassThru
  $result=Join-Path $PSScriptRoot '安装结果.txt'
  if(Test-Path -LiteralPath $result){Get-Content -LiteralPath $result -Encoding UTF8}
  if($process.ExitCode -ne 0){throw '安装未完成，请查看安装结果.txt'}
  exit 0
 }
 # Installing drivers while a host is running can invalidate its active DLLs.
 if(@(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -match '^(audcore(-cpu)?|声核)$'}).Count){throw '请先正常退出声核，再运行安装；也请关闭正在使用此 ASIO 驱动的其他音频软件'}
 function Registered-Driver {
  $registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey('LocalMachine','Registry64')
  try {
   $asio=$registry.OpenSubKey('SOFTWARE\ASIO')
   if(!$asio){return $false}
   try {
    foreach($name in $asio.GetSubKeyNames()){
     $key=$asio.OpenSubKey($name)
     try {
      if(($manifest.product -eq 'FlexASIO' -and $name -eq 'FlexASIO') -or ($manifest.product -eq 'AUR' -and $key.GetValue('CLSID') -eq '{0569D852-1F6A-44A7-B7B5-EFB78B66BE21}')){return $true}
     }finally{$key.Dispose()}
    }
   }finally{$asio.Dispose()}
   return $false
  }finally{$registry.Dispose()}
 }
 if(Registered-Driver){throw "$($manifest.product) 已安装。请在声核中选择该 ASIO 设备；本包不覆盖已有安装或驱动配置"}
 Add-Type -Path (Join-Path $PSScriptRoot 'AudioDefaults.cs')
 $defaults=[AudcoreAsioInstall.Names]::Defaults()
 $reboot=$false
 try {
  if($manifest.product -eq 'FlexASIO'){
   $package=Join-Path $PSScriptRoot 'payload/FlexASIO-1.10b.exe'
   $target=Join-Path $env:ProgramFiles 'FlexASIO'
   $process=Start-Process -FilePath $package -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',('/DIR="'+$target+'"'),('/LOG="'+(Join-Path $PSScriptRoot '安装过程.log')+'"')) -WindowStyle Hidden -Wait -PassThru
   if($process.ExitCode -notin @(0,3010)){throw "FlexASIO 安装失败：$($process.ExitCode)"}
   $reboot=$process.ExitCode -eq 3010
  }elseif($manifest.product -eq 'AUR'){
   & (Join-Path $PSScriptRoot 'aur/install.ps1') -Stage (Join-Path $PSScriptRoot 'payload')
   $code=$LASTEXITCODE
   $result=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'payload/result.json') -Raw -Encoding UTF8 | ConvertFrom-Json
   if($code -ne 0 -or !$result.ok){throw "AUR 安装失败：$($result.error)"}
   $reboot=$result.needs_reboot
  }else{throw '未知安装产品'}
  if(!(Registered-Driver)){throw '安装后未找到 ASIO 注册，请检查安装结果'}
 }finally{[AudcoreAsioInstall.Names]::RestoreDefaults($defaults)}
 $message="$($manifest.product) $($manifest.version) 安装成功。打开声核，在通道输入输出菜单的「ASIO 声卡」中选择此设备。"
 if($manifest.product -eq 'AUR'){$message+=' 在「打开驱动配置」中选择底层 ASIO 声卡和所需路由。'}else{$message+=' 底层设备和缓冲由用户目录的 FlexASIO.toml 配置；未配置时沿用驱动默认值。'}
 if($reboot){$message+=' Windows 提示需要重启，请保存工作后重启再使用。'}
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot '安装结果.txt'),$message,[Text.UTF8Encoding]::new($true))
 Write-Output $message
}catch{
 $message='安装未完成：'+$_.Exception.Message
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot '安装结果.txt'),$message,[Text.UTF8Encoding]::new($true))
 Write-Output $message
 exit 1
}
