﻿param([ValidateSet('Install','UninstallLegacy')][string]$Action='Install',[switch]$Elevated,[switch]$ValidateOnly)
$ErrorActionPreference='Stop'
$installer=Join-Path $PSScriptRoot 'WDM2VST_Ultra_v1.2.0_Setup.exe'
if($Action -eq 'Install'){
    if((Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash -ne 'EDBFB9A1804861BF86368113791051196FB1F59EDBDD9F74E5CB38344AFA875A'){throw '作者原始 v1.2.0 安装包校验失败，停止安装'}
}
if($ValidateOnly){Write-Output '资源校验通过，未安装或卸载';exit 0}
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if(!$admin){
    if($Elevated){throw '管理员授权未生效'}
    $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Action '+$Action+' -Elevated'
    $process=Start-Process -FilePath "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru
    $handle=$process.Handle;$process.WaitForExit();exit $process.ExitCode
}
Add-Type -Path (Join-Path $PSScriptRoot 'AudioNames.cs')
$defaults=[AudcoreCableTest.Names]::Defaults()
$status=0
try {
    if($Action -eq 'Install'){
        # The author installer owns its device, certificates and normal uninstall entry.
        $process=Start-Process -FilePath $installer -Wait -PassThru
        $status=$process.ExitCode
        if($status -notin @(0,3010)){throw ('作者安装器返回错误码 '+$status)}
    } else {
        & (Join-Path $PSScriptRoot 'LegacyUninstall.ps1') -ExitWithStatus
        $status=$LASTEXITCODE
    }
} catch {Write-Error $_ -ErrorAction Continue;$status=1}
finally {
    try {[AudcoreCableTest.Names]::RestoreDefaults($defaults)}
    catch {Write-Error ('默认音频设备恢复失败：'+$_.Exception.Message) -ErrorAction Continue;$status=1}
}
exit $status
