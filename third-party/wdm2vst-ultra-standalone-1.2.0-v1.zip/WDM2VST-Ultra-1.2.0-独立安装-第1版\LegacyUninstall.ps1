﻿param([int]$KeepHostPid=0,[string]$ProgressPipe='',[switch]$ExitWithStatus)
$ErrorActionPreference='Stop'
if($ExitWithStatus -and [Environment]::Is64BitOperatingSystem -and ![Environment]::Is64BitProcess){
    # File-based invocation must use the same registry view as the x64 host.
    $nativeArgs=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-KeepHostPid',"$KeepHostPid",'-ExitWithStatus')
    if($ProgressPipe){$nativeArgs+=@('-ProgressPipe',$ProgressPipe)}
    & "$env:WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" @nativeArgs
    exit $LASTEXITCODE
}
$resultPath=Join-Path $env:ProgramData 'Audcore\WDM2VST-uninstall-result.json'
$result=@{ok=$false;needs_reboot=$false;error=$null;removed_devices=0;removed_drivers=0;removed_plugins=0;certificates_retained=$true;operation_id=[Guid]::NewGuid().ToString();steps=@();current_step=0}
$step=0;$writer=$null;$pipe=$null
$logPath=Join-Path (Split-Path -Parent $resultPath) ('WDM2VST-uninstall-'+$result.operation_id+'.jsonl')
function Write-WdmStep([int]$number,[string]$message,[string]$status='running',[object]$detail=$null){
    $result.current_step=$number
    $entry=@{step=$number;total=7;message=$message;status=$status;time=[DateTime]::UtcNow.ToString('o');detail=$detail}
    $result.steps+=,$entry
    $line=$entry | ConvertTo-Json -Depth 8 -Compress
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    if($writer){$writer.WriteLine($line);$writer.Flush()}
}
try {
    New-Item -ItemType Directory -Path (Split-Path -Parent $resultPath) -Force | Out-Null
    if($ProgressPipe){
        $pipe=[IO.Pipes.NamedPipeClientStream]::new('.',$ProgressPipe,[IO.Pipes.PipeDirection]::Out)
        $pipe.Connect(10000);$writer=[IO.StreamWriter]::new($pipe,[Text.UTF8Encoding]::new($false));$writer.AutoFlush=$true
    }
    Write-WdmStep 1 '正在确认安装来源与插件版本'
    $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw '需要管理员授权'}
    $key='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Audcore-WDM2VST-Ultra'
    if(!(Test-Path -LiteralPath $key)){throw '此设备不是由声核安装；请使用原安装程序卸载'}
    if((Get-ItemProperty -LiteralPath $key).DisplayVersion -ne '1.2.0'){throw '旧安装登记不是固定 v1.2.0，请使用原版本卸载入口'}
    $plugins=(Get-ItemProperty -LiteralPath $key).PluginDirectory
    if(!$plugins){$plugins=Join-Path ${env:CommonProgramFiles} 'VST3\WDM2VST Ultra'}
    $plugins=[IO.Path]::GetFullPath($plugins)
    if($plugins -notmatch '\\(?:components\\WDM2VST|VST3\\WDM2VST Ultra)$'){throw '旧插件目录不在登记的专用组件目录范围内，停止卸载'}
    if(Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{B4A7F2E1-3C5D-4E6F-8A9B-1C2D3E4F5A6B}'){throw '同时存在作者安装登记，请使用作者卸载入口，不执行旧版批量清理'}
    if(!('AudcoreCableTest.Names' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'AudioNames.cs')}
    $owned=@(Get-CimInstance Win32_PnPEntity | Where-Object {$_.HardwareID -contains 'ROOT\WDM2VSTUltra'} | ForEach-Object {$_.PNPDeviceID})
    foreach($id in $owned){
        $inf=(Get-PnpDeviceProperty -InstanceId $id -KeyName DEVPKEY_Device_DriverInfPath -ErrorAction Stop).Data
        if($inf -notmatch '^oem[0-9]+\.inf$' -or (Get-FileHash -LiteralPath (Join-Path $env:WINDIR ('INF\'+$inf))).Hash -ne '4EBCEC3365BCD89B053287F97044A346E5610F65639E4B3E1046C78346AE1DF8'){throw '已安装驱动不是旧声核的固定版本，停止卸载其他版本'}
    }
    $ownedEndpoints=@([AudcoreCableTest.Names]::Inventory() | Where-Object {$_.Owner.StartsWith('{1}.') -and $_.Owner.Substring(4) -in $owned} | ForEach-Object {$_.Id})
    if(@([AudcoreCableTest.Names]::Defaults() | Where-Object {$_.Id -in $ownedEndpoints}).Count){throw '旧跳线仍是系统默认设备，请先选择其他默认播放、录音及通信设备后再卸载'}
    $files=@{
        'WDM2VST Ultra.vst3'='E76D09293DF0A1C65845E350903D846AE56ADC3355046A3C3A68C3EF6D20AD76'
        'VST2WDM Ultra.vst3'='92BBEC27160A04B1394F63CDA6CA7A907D4A579CECBD59B705166B4236519B33'
    }
    foreach($name in $files.Keys){
        $path=Join-Path $plugins $name
        if((Test-Path -LiteralPath $path -PathType Leaf) -and (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $files[$name]){throw "插件已被修改，未卸载：$name"}
    }
    $lock=[Threading.Mutex]::new($false,'Global\AudcoreWDM2VSTInstall')
    try {$ownsLock=$lock.WaitOne(0)} catch [Threading.AbandonedMutexException] {$ownsLock=$true}
    if(!$ownsLock){throw '另一项 WDM2VST 操作正在进行'}
    Write-WdmStep 1 '安装来源与插件版本已确认' 'success'
    # Exclude all helper processes, and keep only the host that released its bridge DLLs.
    Write-WdmStep 2 '正在检查其他声核实例是否占用设备'
    $helpers=@(Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -match '--wdm-(uninstall|install)'} | Select-Object -ExpandProperty ProcessId)
    $listeners=@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalAddress -EQ '127.0.0.1')
    $apps=@(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.Id -ne $PID -and $_.Id -ne $KeepHostPid -and $_.Id -notin $helpers -and $_.Path -and $_.Path.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase) -and
        $_.Path -match '[\\/](声核|audcore)(-|_|\.|$)'
    })
    if($apps.Count){throw '请先保存预设并正常退出所有声核实例，再卸载旧虚拟跳线；不强制结束进程'}
    Write-WdmStep 2 '设备占用检查完成' 'success'
    Write-WdmStep 3 '正在释放 WDM2VST 驱动服务'
    $service=Get-Service -Name WDM2VSTUltra -ErrorAction SilentlyContinue
    if($service -and $service.Status -ne 'Stopped'){
        $stopOutput=& "$env:WINDIR\System32\sc.exe" stop WDM2VSTUltra 2>&1
        $stopCode=$LASTEXITCODE
        Write-WdmStep 3 'WDM2VST 驱动停止结果' 'running' @{exit_code=$stopCode;output=($stopOutput -join "`n")}
        if($stopCode -eq 0){
            try{$service.WaitForStatus([ServiceProcess.ServiceControllerStatus]::Stopped,[TimeSpan]::FromSeconds(5))}catch{}
        }
    }
    Write-WdmStep 3 '正在停用并移除虚拟音频设备'
    $devices=@(Get-CimInstance Win32_PnPEntity -Filter "PNPDeviceID LIKE 'ROOT\\MEDIA%'" | Where-Object {
        $_.HardwareID -contains 'ROOT\WDM2VSTUltra'
    })
    foreach($device in $devices){
        $disableOutput=& "$env:WINDIR\System32\pnputil.exe" /disable-device $device.PNPDeviceID 2>&1
        $disableCode=$LASTEXITCODE
        Write-WdmStep 3 '虚拟设备停用结果' 'running' @{device=$device.PNPDeviceID;exit_code=$disableCode;output=($disableOutput -join "`n")}
        # No forced stop: a driver may reject stop and still allow normal removal.
        $output=& "$env:WINDIR\System32\pnputil.exe" /remove-device $device.PNPDeviceID 2>&1
        Write-WdmStep 3 '虚拟设备移除结果' 'running' @{device=$device.PNPDeviceID;exit_code=$LASTEXITCODE;output=($output -join "`n")}
        if($LASTEXITCODE -notin @(0,3010)){throw "无法移除 WDM2VST 设备：$($output -join ' ')"}
        if($LASTEXITCODE -eq 3010 -or ($output -join ' ') -match '重启|restart|reboot'){$result.needs_reboot=$true}
        $result.removed_devices++
    }
    Write-WdmStep 3 '虚拟音频设备已移除' 'success'
    Write-WdmStep 4 '正在移除固定版本驱动包'
    # Only delete driver packages whose INF bytes exactly match the pinned v1.2.0 release.
    $infHash='4EBCEC3365BCD89B053287F97044A346E5610F65639E4B3E1046C78346AE1DF8'
    foreach($inf in Get-ChildItem -LiteralPath (Join-Path $env:WINDIR 'INF') -Filter 'oem*.inf' -File){
        if((Get-FileHash -LiteralPath $inf.FullName -Algorithm SHA256).Hash -ne $infHash){continue}
        $output=& "$env:WINDIR\System32\pnputil.exe" /delete-driver $inf.Name /uninstall 2>&1
        Write-WdmStep 4 '驱动包移除结果' 'running' @{driver=$inf.Name;exit_code=$LASTEXITCODE;output=($output -join "`n")}
        if($LASTEXITCODE -notin @(0,3010)){throw "无法卸载 WDM2VST 驱动：$($output -join ' ')"}
        if($LASTEXITCODE -eq 3010 -or ($output -join ' ') -match '重启|restart|reboot'){$result.needs_reboot=$true}
        $result.removed_drivers++
    }
    Write-WdmStep 4 '固定版本驱动包已移除' 'success'
    Write-WdmStep 5 '正在删除虚拟设备插件'
    foreach($name in $files.Keys){
        $path=Join-Path $plugins $name
        if(!(Test-Path -LiteralPath $path -PathType Leaf)){continue}
        if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $files[$name]){throw "插件已被修改，未删除：$name"}
        Remove-Item -LiteralPath $path -Force
        $result.removed_plugins++
    }
    if((Test-Path -LiteralPath $plugins) -and !@(Get-ChildItem -LiteralPath $plugins -Force).Count){Remove-Item -LiteralPath $plugins}
    Write-WdmStep 5 '虚拟设备插件已删除' 'success'
    Write-WdmStep 6 '正在核对卸载登记'
    Write-WdmStep 6 '保留卸载登记直到设备核对完成' 'success'
    Write-WdmStep 7 '正在核对卸载结果'
    $remaining=@(Get-CimInstance Win32_PnPEntity -Filter "PNPDeviceID LIKE 'ROOT\\MEDIA%'" | Where-Object {$_.Present -eq $true -and $_.HardwareID -contains 'ROOT\WDM2VSTUltra'})
    if($remaining.Count -and !$result.needs_reboot){throw '卸载后虚拟设备仍然存在'}
    foreach($name in $files.Keys){if(Test-Path -LiteralPath (Join-Path $plugins $name)){throw "卸载后插件仍然存在：$name"}}
    if(Test-Path -LiteralPath $key){Remove-Item -LiteralPath $key}
    $result.ok=$true
    Write-WdmStep 7 $(if($result.needs_reboot){'卸载完成，需要重启 Windows'}else{'卸载完成，已核对设备与插件'}) 'success'
} catch {$result.error=$_.Exception.Message;try{Write-WdmStep $result.current_step ('卸载失败：'+$result.error) 'failed'}catch{}}
finally {
    if($ownsLock){$lock.ReleaseMutex()}
    if($lock){$lock.Dispose()}
    New-Item -ItemType Directory -Path (Split-Path -Parent $resultPath) -Force | Out-Null
    $result | ConvertTo-Json -Depth 10 -Compress | Set-Content -LiteralPath $resultPath -Encoding UTF8
    if($writer){$writer.WriteLine((@{result=$result} | ConvertTo-Json -Depth 10 -Compress));$writer.Dispose()}
    if($pipe){$pipe.Dispose()}
}
if($ExitWithStatus){
    if(!$result.ok){exit 1}
    if($result.needs_reboot){exit 3010}
    exit 0
}
