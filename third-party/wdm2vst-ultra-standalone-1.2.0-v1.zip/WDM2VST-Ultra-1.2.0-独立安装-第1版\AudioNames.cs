﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace AudcoreCableTest {
    [StructLayout(LayoutKind.Sequential)] public struct Key {
        public Guid format; public uint id;
        public Key(string guid, uint pid) { format = new Guid(guid); id = pid; }
    }
    [StructLayout(LayoutKind.Explicit, Size = 24)] public struct Value {
        [FieldOffset(0)] public ushort type;
        [FieldOffset(8)] public IntPtr text;
    }
    [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Store {
        void GetCount(out uint count); void GetAt(uint index, out Key key);
        void GetValue(ref Key key, out Value value); void SetValue(ref Key key, ref Value value); void Commit();
    }
    [ComImport, Guid("d666063f-1587-4e43-81f1-b948e807363f"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Device {
        void Activate(ref Guid iid, uint context, IntPtr parameters, out IntPtr result);
        void OpenPropertyStore(uint mode, out Store store);
        void GetId([MarshalAs(UnmanagedType.LPWStr)] out string id); void GetState(out uint state);
    }
    [ComImport, Guid("0bd7a1be-7a1a-44db-8397-cc5392387b5e"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Collection { void GetCount(out uint count); void Item(uint index, out Device device); }
    [ComImport, Guid("a95664d2-9614-4f35-a746-de8db63617e6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Enumerator {
        void EnumAudioEndpoints(int flow, uint mask, out Collection devices);
        void GetDefaultAudioEndpoint(int flow, int role, out Device device);
        void GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out Device device);
    }
    [ComImport,Guid("77aa99a0-1bd6-484f-8bc7-2c654c9a9b6f"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface SessionManager {
        void GetAudioSessionControl(ref Guid id,uint flags,out IntPtr control);
        void GetSimpleAudioVolume(ref Guid id,uint flags,out IntPtr volume);
        void GetSessionEnumerator(out SessionCollection sessions);
    }
    [ComImport,Guid("e2f5bb11-0570-40ca-acdd-3aa01277dee8"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface SessionCollection { void GetCount(out int count); void GetSession(int index,out Session session); }
    [ComImport,Guid("bfb7ff88-7239-4fc9-8fa2-07c950be9c6d"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface Session {
        void GetState(out int state); void GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        void SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name,ref Guid context);
        void GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        void SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path,ref Guid context);
        void GetGroupingParam(out Guid grouping); void SetGroupingParam(ref Guid grouping,ref Guid context);
        void RegisterAudioSessionNotification(IntPtr notification);void UnregisterAudioSessionNotification(IntPtr notification);
        void GetSessionIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        void GetSessionInstanceIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        void GetProcessId(out uint process);
    }
    public class AudioClient { public string Endpoint; public uint Process; }
    public class Endpoint { public string Id, Owner, Name; public int Flow; public uint State; }
    public class DefaultEndpoint { public string Id; public int Flow, Role; }
    public static class Names {
        delegate bool WindowCallback(IntPtr window,IntPtr data);
        [DllImport("user32.dll")] static extern bool EnumWindows(WindowCallback callback,IntPtr data);
        [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent,WindowCallback callback,IntPtr data);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32.dll",SetLastError=true)] static extern bool PostMessageW(IntPtr window,uint message,IntPtr wparam,IntPtr lparam);
        public static int CloseClientWindows(uint process) {
            int count=0;
            EnumWindows((window,data)=>{
                if(!IsWindowVisible(window))return true;
                uint owner;GetWindowThreadProcessId(window,out owner);bool belongs=owner==process;
                if(!belongs){
                    try {
                        if(System.Diagnostics.Process.GetProcessById((int)owner).ProcessName!="ApplicationFrameHost")return true;
                    }catch(ArgumentException){return true;}
                    EnumChildWindows(window,(child,unused)=>{uint id;GetWindowThreadProcessId(child,out id);if(id==process)belongs=true;return !belongs;},IntPtr.Zero);
                }
                if(belongs && PostMessageW(window,0x10,IntPtr.Zero,IntPtr.Zero))count++;
                return true;
            },IntPtr.Zero);
            return count;
        }
        public static AudioClient[] Clients(string[] instances) {
            Enumerator enumerator=(Enumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("bcde0395-e52f-467c-8e3d-c4579291692e")));
            var result=new List<AudioClient>();
            try {
                foreach(Endpoint endpoint in Inventory()) {
                    if(endpoint.State!=1 || !Array.Exists(instances,id=>String.Equals(endpoint.Owner,"{1}."+id,StringComparison.OrdinalIgnoreCase))) continue;
                    Device device=null; object managerObject=null; SessionCollection sessions=null;
                    try {
                        enumerator.GetDevice(endpoint.Id,out device);
                        Guid iid=new Guid("77aa99a0-1bd6-484f-8bc7-2c654c9a9b6f"); IntPtr pointer;
                        device.Activate(ref iid,23,IntPtr.Zero,out pointer);
                        try { managerObject=Marshal.GetObjectForIUnknown(pointer); } finally { Marshal.Release(pointer); }
                        ((SessionManager)managerObject).GetSessionEnumerator(out sessions);
                        int count;sessions.GetCount(out count);
                        for(int i=0;i<count;i++) {
                            Session session;sessions.GetSession(i,out session);
                            try { int state;uint process; session.GetState(out state);session.GetProcessId(out process);
                                if(state==1 && process!=0)result.Add(new AudioClient {Endpoint=endpoint.Id,Process=process});
                            } finally {Marshal.ReleaseComObject(session);}
                        }
                    } finally {if(sessions!=null)Marshal.ReleaseComObject(sessions);if(managerObject!=null)Marshal.ReleaseComObject(managerObject);if(device!=null)Marshal.ReleaseComObject(device);}
                }
            } finally {Marshal.ReleaseComObject(enumerator);}
            return result.ToArray();
        }
        static Key owner = new Key("b3f8fa53-0004-438e-9003-51a46e139bfc", 2);
        static Key friendly = new Key("a45c254e-df1c-4efd-8020-67d146a850e0", 14);
        static Key description = new Key("a45c254e-df1c-4efd-8020-67d146a850e0", 2);
        static Key suffix = new Key("b3f8fa53-0004-438e-9003-51a46e139bfc", 6);
        [DllImport("ole32.dll")] static extern int PropVariantClear(ref Value value);
        [DllImport("cfgmgr32.dll", CharSet=CharSet.Unicode)] static extern uint CM_Locate_DevNodeW(out uint node, string id, uint flags);
        [DllImport("cfgmgr32.dll", CharSet=CharSet.Unicode)] static extern uint CM_Set_DevNode_PropertyW(uint node, ref Key key, uint type, byte[] data, uint size, uint flags);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int SetProperty(IntPtr self, [MarshalAs(UnmanagedType.LPWStr)] string id, int endpoint, ref Key key, ref Value value);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int SetDefault(IntPtr self, [MarshalAs(UnmanagedType.LPWStr)] string id, int role);
        public static DefaultEndpoint[] Defaults() {
            Enumerator enumerator=(Enumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("bcde0395-e52f-467c-8e3d-c4579291692e")));
            var result=new List<DefaultEndpoint>();
            try {
                for(int flow=0;flow<2;flow++) for(int role=0;role<3;role++) {
                    string id=null; Device device=null;
                    try { enumerator.GetDefaultAudioEndpoint(flow,role,out device); device.GetId(out id); }
                    catch(COMException error) { if(error.ErrorCode!=unchecked((int)0x80070490)) throw; }
                    finally { if(device!=null) Marshal.ReleaseComObject(device); }
                    result.Add(new DefaultEndpoint {Id=id,Flow=flow,Role=role});
                }
            } finally { Marshal.ReleaseComObject(enumerator); }
            return result.ToArray();
        }
        public static DefaultEndpoint[] DefaultChanges(DefaultEndpoint[] saved, DefaultEndpoint[] current) {
            var result=new List<DefaultEndpoint>();
            foreach(DefaultEndpoint original in saved) {
                DefaultEndpoint actual=Array.Find(current,e=>e.Flow==original.Flow && e.Role==original.Role);
                if(actual==null || !String.Equals(original.Id,actual.Id,StringComparison.OrdinalIgnoreCase)) result.Add(original);
            }
            return result.ToArray();
        }
        public static void RestoreDefaults(DefaultEndpoint[] saved) {
            DefaultEndpoint[] changes=DefaultChanges(saved,Defaults());
            if(changes.Length==0) return; // No writable COM object for unchanged defaults.
            object policyObject=Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("870af99c-171d-4f9e-af0d-e63df40c2bc9")));
            IntPtr unknown=Marshal.GetIUnknownForObject(policyObject),policy=IntPtr.Zero;
            try {
                foreach(DefaultEndpoint entry in changes) {
                    if(String.IsNullOrEmpty(entry.Id)) throw new Exception("There was no default endpoint before installation; cannot restore an empty default via this API");
                    int error=unchecked((int)0x80004002);
                    foreach(string version in new string[]{"ca286fc3-91fd-42c3-8e9b-caafa66242e3","6be54be8-a068-4875-a49d-0c2966473b11","f8679f50-850a-41cf-9c72-430f290290c8"}) {
                        Guid iid=new Guid(version);error=Marshal.QueryInterface(unknown,ref iid,out policy);
                        if(error<0)continue;
                        try {
                            IntPtr table=Marshal.ReadIntPtr(policy);
                            SetDefault set=(SetDefault)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(table,13*IntPtr.Size),typeof(SetDefault));
                            error=set(policy,entry.Id,entry.Role);
                        } finally {Marshal.Release(policy);policy=IntPtr.Zero;}
                        if(error!=unchecked((int)0x80004001) && error!=unchecked((int)0x80004002))break;
                    }
                    Marshal.ThrowExceptionForHR(error);
                }
            } finally {if(policy!=IntPtr.Zero) Marshal.Release(policy); Marshal.Release(unknown); Marshal.ReleaseComObject(policyObject);}
            for(int wait=0;wait<20;wait++) {
                if(DefaultChanges(saved,Defaults()).Length==0)return;
                System.Threading.Thread.Sleep(100);
            }
            throw new Exception("Default endpoint restoration verification failed");
        }
        static string Read(Store store, Key key) {
            Value value; store.GetValue(ref key, out value);
            try { return value.type == 31 ? Marshal.PtrToStringUni(value.text) : ""; }
            finally { PropVariantClear(ref value); }
        }
        public static Endpoint[] Inventory() {
            Enumerator enumerator = (Enumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("bcde0395-e52f-467c-8e3d-c4579291692e")));
            var result = new List<Endpoint>();
            try {
                for (int flow=0; flow<2; flow++) {
                    Collection list; enumerator.EnumAudioEndpoints(flow, 15, out list);
                    try {
                        uint count; list.GetCount(out count);
                        for(uint i=0;i<count;i++) {
                            Device device; list.Item(i,out device);
                            try {
                                uint state; device.GetState(out state); if(state==4) continue;
                                Store store; device.OpenPropertyStore(0,out store);
                                try { string id; device.GetId(out id); result.Add(new Endpoint {Id=id, Owner=Read(store,owner), Name=Read(store,friendly), Flow=flow, State=state}); }
                                finally { Marshal.ReleaseComObject(store); }
                            } catch(COMException error) {
                                // An endpoint can disappear between enumeration and property reads.
                                if(error.ErrorCode!=unchecked((int)0xe000020b) && error.ErrorCode!=unchecked((int)0x80070490) && error.ErrorCode!=unchecked((int)0x88890004)) throw;
                            } finally { Marshal.ReleaseComObject(device); }
                        }
                    } finally { Marshal.ReleaseComObject(list); }
                }
            } finally { Marshal.ReleaseComObject(enumerator); }
            return result.ToArray();
        }
        public static void Adapter(string id, string name) {
            uint node; uint error=CM_Locate_DevNodeW(out node,id,0); if(error!=0) throw new Exception("Locate adapter: "+error);
            byte[] data=System.Text.Encoding.Unicode.GetBytes(name+"\0");
            error=CM_Set_DevNode_PropertyW(node,ref friendly,0x12,data,(uint)data.Length,0);
            if(error!=0) throw new Exception("Rename adapter: "+error);
            // EndpointBuilder derives its numbered adapter label from DeviceDesc.
            // Give each owned adapter a distinct description before restarting it.
            error=CM_Set_DevNode_PropertyW(node,ref description,0x12,data,(uint)data.Length,0);
            if(error!=0) throw new Exception("Rename adapter description: "+error);
        }
        static void Write(SetProperty set, IntPtr policy, string id, Key key, string text) {
            Value value=new Value {type=31,text=Marshal.StringToCoTaskMemUni(text)};
            try {
                int error=set(policy,id,0,ref key,ref value);
                if(error<0) throw new COMException("Rename property "+key.format+"/"+key.id,error);
            }
            finally { PropVariantClear(ref value); }
        }
        public static void Rename(string endpointId, string instanceId, string name, string adapter, bool verifyImmediate=true) {
            // Recheck ownership immediately before each mutation. Never match mutable names.
            Endpoint endpoint=Array.Find(Inventory(),e=>e.Id==endpointId);
            if(endpoint==null || !String.Equals(endpoint.Owner,"{1}."+instanceId,StringComparison.OrdinalIgnoreCase)) throw new Exception("Endpoint ownership mismatch");
            object policyObject=Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("870af99c-171d-4f9e-af0d-e63df40c2bc9")));
            IntPtr unknown=Marshal.GetIUnknownForObject(policyObject), policy=IntPtr.Zero;
            try {
                Guid iid=new Guid("f8679f50-850a-41cf-9c72-430f290290c8"); Marshal.ThrowExceptionForHR(Marshal.QueryInterface(unknown,ref iid,out policy));
                IntPtr table=Marshal.ReadIntPtr(policy);
                SetProperty set=(SetProperty)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(table,12*IntPtr.Size),typeof(SetProperty));
                Write(set,policy,endpointId,description,name); Write(set,policy,endpointId,suffix,adapter);
                // FriendlyName is computed from description + adapter suffix on this API.
                // Writing it directly can return E_ACCESSDENIED even after successful rename.
            } finally { if(policy!=IntPtr.Zero) Marshal.Release(policy); Marshal.Release(unknown); Marshal.ReleaseComObject(policyObject); }
            endpoint=Array.Find(Inventory(),e=>e.Id==endpointId);
            string expected=String.IsNullOrEmpty(adapter) ? name : name+" ("+adapter+")";
            if(verifyImmediate && (endpoint==null || endpoint.Name!=expected)) throw new Exception("Endpoint name did not persist: "+endpointId+"; actual="+(endpoint==null ? "missing" : endpoint.Name));
        }
    }
}
