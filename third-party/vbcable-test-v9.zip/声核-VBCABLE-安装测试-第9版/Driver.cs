﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
namespace AudcoreCableTest {
    public static class Driver {
        [StructLayout(LayoutKind.Sequential)] struct Info { public uint size; public Guid classId; public uint node; public UIntPtr reserved; }
        [DllImport("setupapi.dll",SetLastError=true)] static extern IntPtr SetupDiCreateDeviceInfoList(ref Guid cls,IntPtr hwnd);
        [DllImport("setupapi.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool SetupDiCreateDeviceInfoW(IntPtr list,string name,ref Guid cls,string description,IntPtr hwnd,uint flags,ref Info info);
        [DllImport("setupapi.dll",SetLastError=true)] static extern bool SetupDiSetDeviceRegistryPropertyW(IntPtr list,ref Info info,uint property,byte[] bytes,uint size);
        [DllImport("setupapi.dll",SetLastError=true)] static extern bool SetupDiCallClassInstaller(uint function,IntPtr list,ref Info info);
        [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr list);
        [DllImport("newdev.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool UpdateDriverForPlugAndPlayDevicesW(IntPtr hwnd,string hardware,string inf,uint flags,out bool reboot);
        static void Check(bool ok) { if(!ok) throw new Win32Exception(Marshal.GetLastWin32Error()); }
        public static string Instance(int index) {
            if(index<0 || index>=16) throw new ArgumentOutOfRangeException("index");
            return "ROOT\\AUDCORE_VBCABLE\\"+(index==0 ? "MUSIC" : index==1 ? "MIX" : index==2 ? "VOICE" : "CABLE"+(index+1).ToString("00"));
        }
        public static void Create(int index) {
            Guid cls=new Guid("4d36e96c-e325-11ce-bfc1-08002be10318");
            IntPtr list=SetupDiCreateDeviceInfoList(ref cls,IntPtr.Zero);
            if(list==new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error());
            try {
                Info info=new Info {size=(uint)Marshal.SizeOf(typeof(Info))};
                Check(SetupDiCreateDeviceInfoW(list,Instance(index),ref cls,"VB-CABLE",IntPtr.Zero,0,ref info));
                byte[] hardware=Encoding.Unicode.GetBytes("VBAudioVACWDM\0\0");
                Check(SetupDiSetDeviceRegistryPropertyW(list,ref info,1,hardware,(uint)hardware.Length));
                Check(SetupDiCallClassInstaller(0x19,list,ref info));
            } finally {SetupDiDestroyDeviceInfoList(list);}
        }
        public static bool Bind(string inf) {
            bool reboot; Check(UpdateDriverForPlugAndPlayDevicesW(IntPtr.Zero,"VBAudioVACWDM",inf,1,out reboot)); return reboot;
        }
    }
}
