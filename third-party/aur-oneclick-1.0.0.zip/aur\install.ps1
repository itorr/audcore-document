﻿param([Parameter(Mandatory=$true)][string]$Stage,[switch]$VerifyOnly)
$ErrorActionPreference='Stop'
$hashes=@{
 'devcon.exe'='c447d8fcf6a8752662a400d90798d4e7a576a86f7a8369a309ade4701527131a'
 'SarAsio.dll'='27bc1dfc5871b4008db1fc77f83d464a06e531e7120323b60247129f52317f20'
 'SarCtl.exe'='77f92de6b7d2b9659e1172d0e36bb6897fe4690204bbbdc433576aa61ebaf91a'
 'synchronousaudiorouter.cat'='f25a915efb9768efcf289a6816afdd09405e589f46482f586d6f42d1982f7810'
 'SynchronousAudioRouter.inf'='7fadaea4aa838f90a404e6789ed663b18f3be8063153189f62c7d087afb01f69'
 'SynchronousAudioRouter.sys'='7a8da65a4bca151049373856f0248c611bad2b4c57c8ffcc3b3d0b9e8bd1df98'
}
function Verify-Components([string]$Root) {
 foreach($name in $hashes.Keys){
  if((Get-FileHash -LiteralPath (Join-Path $Root $name) -Algorithm SHA256).Hash -ne $hashes[$name]){throw "AUR 组件校验失败：$name"}
 }
}
$result=@{ok=$false;needs_reboot=$false;steps=@()}
try {
 $source=[IO.Path]::GetFullPath($Stage)
 Verify-Components $source
 if($VerifyOnly){$result.ok=$true;$result.verified_only=$true}
 else {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  if(!([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw '请授予 Windows 管理员权限'}
  $target=Join-Path $env:ProgramFiles 'Audcore\ThirdParty\AUR'
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  foreach($name in $hashes.Keys){Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $target $name)}
  Verify-Components $target
  $inf=Join-Path $target 'SynchronousAudioRouter.inf'
  $output=& "$env:SystemRoot\System32\pnputil.exe" /add-driver $inf /install 2>&1
  $code=$LASTEXITCODE
  $result.steps+=@{step='driver_store';exit_code=$code;output=($output -join "`n")}
  if($code -notin @(0,3010)){throw "AUR 驱动安装失败：$code"}
  if($code -eq 3010){$result.needs_reboot=$true}
  $existing=@(Get-CimInstance Win32_PnPEntity -Filter "Service='SynchronousAudioRouter'" | Where-Object {$_.Present -ne $false})
  $verb=if($existing.Count){'update'}else{'install'}
  $output=& (Join-Path $target 'devcon.exe') $verb $inf 'SW\{0BCFFA5C-E754-48CF-A783-A64C0DC0BB2C}' 2>&1
  $code=$LASTEXITCODE
  $result.steps+=@{step='device';exit_code=$code;output=($output -join "`n")}
  if($code -notin @(0,1)){throw "AUR 设备安装失败：$code"}
  if($code -eq 1){$result.needs_reboot=$true}
  $registration=Start-Process -FilePath "$env:SystemRoot\System32\regsvr32.exe" -ArgumentList @('/s',('"'+(Join-Path $target 'SarAsio.dll')+'"')) -WindowStyle Hidden -Wait -PassThru
  $result.steps+=@{step='asio_registration';exit_code=$registration.ExitCode}
  if($registration.ExitCode -ne 0){throw "AUR 接口注册失败：$($registration.ExitCode)"}
  $devices=@(Get-CimInstance Win32_PnPEntity -Filter "Service='SynchronousAudioRouter'" | Where-Object {$_.Present -ne $false})
  if(!$devices.Count){throw 'AUR 安装后未检测到设备'}
  if(@($devices | Where-Object {$_.ConfigManagerErrorCode -ne 0}).Count -and !$result.needs_reboot){throw 'Windows 未能加载 AUR 驱动，请检查签名兼容性或重启 Windows 后重试'}
  $result.ok=$true;$result.directory=$target
 }
}catch{$result.error=$_.Exception.Message}
[IO.File]::WriteAllText((Join-Path $Stage 'result.json'),($result | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
if(!$result.ok){exit 1}
