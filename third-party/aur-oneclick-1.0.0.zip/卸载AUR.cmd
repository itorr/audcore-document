@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-AUR.ps1"
set "result=%errorlevel%"
pause
exit /b %result%
