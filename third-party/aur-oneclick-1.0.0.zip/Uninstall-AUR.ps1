﻿$ErrorActionPreference='Stop'
if([Environment]::Is64BitOperatingSystem -and ![Environment]::Is64BitProcess){
 & "$env:WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
 exit $LASTEXITCODE
}
try {
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 if(!([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $p=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"')) -Verb RunAs -WindowStyle Hidden -Wait -PassThru
  if(Test-Path -LiteralPath (Join-Path $PSScriptRoot '卸载结果.txt')){Get-Content -LiteralPath (Join-Path $PSScriptRoot '卸载结果.txt') -Encoding UTF8}
  exit $p.ExitCode
 }
 if(@(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -match '^(audcore(-cpu)?|声核)$'}).Count){throw '请先正常退出声核及正在使用此 ASIO 驱动的音频软件'}
 Add-Type -Path (Join-Path $PSScriptRoot 'AudioDefaults.cs')
 $defaults=[AudcoreAsioInstall.Names]::Defaults()
 try {
  & (Join-Path $PSScriptRoot 'aur/uninstall.ps1') -Stage $PSScriptRoot
  $code=$LASTEXITCODE
  $result=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'result.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if($code -ne 0 -or !$result.ok){throw $result.error}
 }finally{[AudcoreAsioInstall.Names]::RestoreDefaults($defaults)}
 $message='AUR 已卸载，原驱动配置保留。'
 if($result.needs_reboot){$message+=' 请保存工作后重启 Windows。'}
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot '卸载结果.txt'),$message,[Text.UTF8Encoding]::new($true))
 Write-Output $message
}catch{
 $message='卸载未完成：'+$_.Exception.Message
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot '卸载结果.txt'),$message,[Text.UTF8Encoding]::new($true))
 Write-Output $message
 exit 1
}
