﻿param([Parameter(Mandatory=$true)][string]$Stage,[switch]$VerifyOnly)
$ErrorActionPreference='Stop'
$result=@{ok=$false;needs_reboot=$false;steps=@()}
try {
 $dll=(Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Classes\CLSID\{0569D852-1F6A-44A7-B7B5-EFB78B66BE21}\InprocServer32').'(default)'
 if((Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash -ne '27bc1dfc5871b4008db1fc77f83d464a06e531e7120323b60247129f52317f20'){throw '当前 AUR 接口版本无法验证，请使用原安装程序卸载'}
 $root=Split-Path -Parent $dll
 $devcon=Join-Path $root 'devcon.exe'
 if((Get-FileHash -LiteralPath $devcon -Algorithm SHA256).Hash -ne 'c447d8fcf6a8752662a400d90798d4e7a576a86f7a8369a309ade4701527131a'){throw 'AUR 设备管理组件校验失败'}
 $devices=@(Get-CimInstance Win32_PnPEntity -Filter "Service='SynchronousAudioRouter'" | Where-Object {$_.HardwareID -contains 'SW\{0BCFFA5C-E754-48CF-A783-A64C0DC0BB2C}'})
 if(!$devices.Count){throw '没有找到可验证的 AUR 设备'}
 $signed=@(Get-CimInstance Win32_PnPSignedDriver | Where-Object {$_.DeviceID -in $devices.DeviceID})
 $infs=@($signed.InfName | Sort-Object -Unique)
 if(!$infs.Count){throw '无法验证 AUR 驱动安装记录'}
 foreach($inf in $infs){
  if($inf -notmatch '^oem\d+\.inf$' -or (Get-FileHash -LiteralPath (Join-Path "$env:SystemRoot\INF" $inf) -Algorithm SHA256).Hash -ne '7fadaea4aa838f90a404e6789ed663b18f3be8063153189f62c7d087afb01f69'){throw '当前 AUR 驱动版本无法验证，请使用原安装程序卸载'}
 }
 $result.devices=@($devices.DeviceID);$result.driver_packages=$infs
 if($VerifyOnly){$result.verified_only=$true}
 else {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  if(!([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw '请授予 Windows 管理员权限'}
  $registration=Start-Process -FilePath "$env:SystemRoot\System32\regsvr32.exe" -ArgumentList @('/u','/s',('"'+$dll+'"')) -WindowStyle Hidden -Wait -PassThru
  if($registration.ExitCode -ne 0){throw "AUR 接口注销失败：$($registration.ExitCode)"}
  foreach($device in $devices){
   $output=& $devcon remove ('@'+$device.DeviceID) 2>&1
   $code=$LASTEXITCODE;$result.steps+=@{step='device';exit_code=$code;output=($output -join "`n")}
   if($code -notin @(0,1)){throw "AUR 设备卸载失败：$code"}
   if($code -eq 1){$result.needs_reboot=$true}
  }
  foreach($inf in $infs){
   $output=& "$env:SystemRoot\System32\pnputil.exe" /delete-driver $inf /uninstall 2>&1
   $code=$LASTEXITCODE;$result.steps+=@{step='driver_store';exit_code=$code;output=($output -join "`n")}
   if($code -notin @(0,3010)){throw "AUR 驱动卸载失败：$code"}
   if($code -eq 3010){$result.needs_reboot=$true}
  }
 }
 $result.ok=$true
}catch{$result.error=$_.Exception.Message}
[IO.File]::WriteAllText((Join-Path $Stage 'result.json'),($result | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
if(!$result.ok){exit 1}
