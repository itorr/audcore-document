﻿function Cable-Role([int]$index){
    if($index -eq 0){return 'music'};if($index -eq 1){return 'mix'};if($index -eq 2){return 'voice'}
    return ('cable{0:d2}' -f ($index+1))
}
function Cable-Name([int]$index){
    if($index -eq 0){return '输入伴奏'};if($index -eq 1){return '输入混音'};if($index -eq 2){return '输入人声'}
    return ('输入跳线'+($index+1))
}
function Cable-Adapter([int]$index){
    return 'VB-CABLE '+((Cable-Name $index) -replace '^输入','')
}
function Cable-EndpointName([int]$index,[int]$flow){
    if($flow -notin @(0,1)){throw '未知跳线端点方向'}
    $name=Cable-Name $index
    if($flow -eq 1){return ($name -replace '^输入','输出')}
    return $name
}
function New-ReplacementPlan($devices,$endpoints,$registered,$defaults,[int]$count){
    $migration=@();$used=@($registered | ForEach-Object {[int]$_.index})
    foreach($device in @($devices | Sort-Object PNPDeviceID)){
        $known=@($registered | Where-Object {$_.instance -ieq $device.PNPDeviceID})
        if($known.Count -eq 1){$index=[int]$known[0].index}
        else {$index=0;while($index -in $used){$index++};$used+=$index}
        foreach($endpoint in @($endpoints | Where-Object {$_.Owner -ieq ('{1}.'+$device.PNPDeviceID)})){
            $migration+=[pscustomobject]@{id=$endpoint.Id;index=$index;flow=$endpoint.Flow}
        }
    }
    foreach($entry in $defaults){
        $old=@($migration | Where-Object {$_.id -ieq $entry.Id})
        if($old.Count -and [int]$old[0].index -ge $count){throw '减少跳线数量会移除仍作为默认设备的跳线；请先更改 Windows 默认设备再安装'}
    }
    return $migration
}
function Resolve-ReplacementDefaults($saved,$migration,$inventory,$registered,[switch]$RequireResolved){
    foreach($original in $saved){
        $id=$original.Id
        $old=@($migration | Where-Object {$_.id -ieq $id})
        if($old.Count -eq 1){
            $new=@($registered | Where-Object {[int]$_.index -eq [int]$old[0].index})
            $target=@($inventory | Where-Object {$_.Flow -eq $original.Flow -and $new.Count -eq 1 -and $_.Owner -ieq ('{1}.'+$new[0].instance) -and $_.State -eq 1})
            if($target.Count -eq 1){$id=$target[0].Id}
            elseif(@($inventory | Where-Object {$_.Id -ieq $id -and $_.State -eq 1}).Count -eq 0){
                if($RequireResolved){throw ('原默认跳线尚未重新接通：'+$original.Id)}
                continue
            }
        }
        [pscustomobject]@{Id=$id;Flow=$original.Flow;Role=$original.Role}
    }
}
