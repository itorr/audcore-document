﻿param(
    [ValidateSet('Install','Rename','Verify','Uninstall','Inspect')][string]$Action='Install',
    [ValidateRange(1,16)][int]$CableCount=3,
    [switch]$Elevated
)
$ErrorActionPreference='Stop'
$packageVersion='8'
# Keep the v1 state schema and path so repairs reuse already installed instances.
$stateRoot=Join-Path $env:ProgramData 'Audcore\VBCableTest-v1'
$statePath=Join-Path $stateRoot 'state.json'
$resultPath=Join-Path $PSScriptRoot '测试结果.txt'
if($Action -eq 'Inspect'){
    Add-Type -Path (Join-Path $PSScriptRoot 'AudioNames.cs')
    $instances=@(Get-CimInstance Win32_PnPEntity | Where-Object {$_.HardwareID -contains 'VBAudioVACWDM' -or $_.HardwareID -contains 'ROOT\VBAudioVACWDM'} | ForEach-Object {$_.PNPDeviceID})
    $clients=@([AudcoreCableTest.Names]::Clients([string[]]$instances))
    foreach($clientPid in @($clients.Process | Select-Object -Unique)){
        $process=Get-Process -Id $clientPid -ErrorAction SilentlyContinue
        if($process){Write-Output ($process.ProcessName+' · PID '+$clientPid)}
    }
    if(!$clients.Count){Write-Output '未发现普通 VB-CABLE 的活动应用音频会话；驱动自身否决或内核占用不一定表现为应用会话'}
    exit 0
}
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if(!$admin){
    if($Elevated){throw '管理员授权未生效'}
    try {
        $arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Action '+$Action+' -CableCount '+$CableCount+' -Elevated'
        $process=Start-Process -FilePath "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru
        $processHandle=$process.Handle
        $process.WaitForExit()
        if(Test-Path -LiteralPath $resultPath){Get-Content -LiteralPath $resultPath -Encoding UTF8}
        exit $process.ExitCode
    } catch {Write-Host ('无法完成管理员授权：'+$_.Exception.Message); exit 1}
}
$log=[Collections.Generic.List[string]]::new()
. (Join-Path $PSScriptRoot 'Reinstall.ps1')
function Note([string]$text){$log.Add((Get-Date -Format 'HH:mm:ss')+' '+$text)}
function Save-State { $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $statePath -Encoding UTF8 }
function Cable-Devices {
    @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.HardwareID -contains 'VBAudioVACWDM' -or $_.HardwareID -contains 'ROOT\VBAudioVACWDM' })
}
function Native([string[]]$arguments){
    $output=& (Join-Path $PSScriptRoot 'driver\devcon.exe') @arguments 2>&1
    $code=$LASTEXITCODE
    Note (($arguments -join ' ')+' => '+$code+' '+($output -join ' '))
    if($code -notin @(0,1)){throw ('驱动工具失败，错误码 '+$code)}
    if($code -eq 1){$script:needsRestart=$true}
    try {Restore-Defaults}catch {Note ('安装过程中暂未恢复默认设备，将在端点重新接通后重试：'+$_.Exception.Message)}
}
function Restore-Defaults([switch]$RequireResolved) {
    if($null -ne $script:savedDefaults){
        $resolved=@(Resolve-ReplacementDefaults $savedDefaults $defaultMigration ([AudcoreCableTest.Names]::Inventory()) @($state.devices) -RequireResolved:$RequireResolved)
        $typed=[AudcoreCableTest.DefaultEndpoint[]]@($resolved | ForEach-Object {
            $entry=New-Object AudcoreCableTest.DefaultEndpoint
            $entry.Id=$_.Id;$entry.Flow=$_.Flow;$entry.Role=$_.Role;$entry
        })
        [AudcoreCableTest.Names]::RestoreDefaults($typed)
    }
}
function Save-Defaults([object[]]$values){
    $script:savedDefaults=@($values | ForEach-Object {
        $entry=New-Object AudcoreCableTest.DefaultEndpoint
        $entry.Id=$_.Id; $entry.Flow=$_.Flow; $entry.Role=$_.Role; $entry
    })
}
function Release-CableClients([string[]]$instances){
    $clients=@([AudcoreCableTest.Names]::Clients($instances))
    $processes=@($clients.Process | Select-Object -Unique | ForEach-Object {Get-Process -Id $_ -ErrorAction SilentlyContinue})
    if(!$processes.Count){Note '未发现 VB-CABLE 活动应用会话';return}
    $started=@{}
    foreach($process in $processes){Note ('占用程序：'+$process.ProcessName+' · PID '+$process.Id)}
    foreach($process in $processes){$started[$process.Id]=$process.StartTime.ToUniversalTime().Ticks}
    Add-Type -AssemblyName System.Windows.Forms
    $names=($processes | ForEach-Object {$_.ProcessName+' (PID '+$_.Id+')'}) -join "`r`n"
    $answer=[Windows.Forms.MessageBox]::Show("这些程序正在使用 VB-CABLE：`r`n"+$names+"`r`n`r`n正常关闭这些程序后继续安装？不会强制 kill 系统服务或声卡进程。",'释放 VB-CABLE 占用',[Windows.Forms.MessageBoxButtons]::YesNo,[Windows.Forms.MessageBoxIcon]::Question)
    if($answer -ne [Windows.Forms.DialogResult]::Yes){throw '已取消关闭占用程序，旧设备未卸载'}
    foreach($process in $processes){
        if($process.ProcessName -in @('audiodg','svchost','System','audcore','声核') -or $process.ProcessName -like 'audcore-*' -or $process.MainModule.FileVersionInfo.ProductName -eq '声核'){throw ('不能通过窗口关闭系统音频或声核进程：'+$process.ProcessName+'；请先停止其 VB-CABLE 路由或通过原生入口正常退出声核')}
        $live=@([AudcoreCableTest.Names]::Clients($instances) | Where-Object {$_.Process -eq $process.Id})
        if(!$live.Count){continue}
        $current=Get-Process -Id $process.Id -ErrorAction SilentlyContinue
        if(!$current -or $current.StartTime.ToUniversalTime().Ticks -ne $started[$process.Id]){continue}
        if(!$process.CloseMainWindow() -and [AudcoreCableTest.Names]::CloseClientWindows([uint32]$process.Id) -eq 0){throw ('无法正常关闭 '+$process.ProcessName+'，请在该程序中停止 VB-CABLE 音频后重试')}
    }
    for($wait=0;$wait -lt 10;$wait++){
        if(@([AudcoreCableTest.Names]::Clients($instances)).Count -eq 0){return}
        Start-Sleep -Milliseconds 500
    }
    throw '占用尚未释放；请完成程序的保存或退出提示，再重试安装'
}
$needsRestart=$false
$savedDefaults=$null
$defaultMigration=@()
$state=$null
$mutex=[Threading.Mutex]::new($false,'Global\AudcoreVBCableTest-v1')
$ownsMutex=$false
try {
    if(![Environment]::Is64BitProcess){throw '需要 64 位 Windows PowerShell'}
    $ownsMutex=$mutex.WaitOne(0)
    if(!$ownsMutex){throw '另一项测试安装正在运行'}
    Note ('声核 VB-CABLE 安装测试包第 '+$packageVersion+' 版 · '+$Action)
    $hashes=@{
        'devcon.exe'='C447D8FCF6A8752662A400D90798D4E7A576A86F7A8369A309ADE4701527131A'
        'vbaudio_cable64_vista.cat'='CC17731E91F2F071E4A108BBA34A2B8DCB69EA5975F4B9C39FCBC670E5CF15FB'
        'vbaudio_cable64_vista.sys'='703572FA9E8AA1616E6B2ABD36B91A4718DE77EADC02AE05ED2C8F304D058AFC'
    }
    $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'driver-hashes.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $hashes['vbMmeCable64_vista.inf']=$manifest.'vbMmeCable64_vista.inf'
    foreach($file in $hashes.Keys){
        $path=Join-Path $PSScriptRoot ('driver\'+$file)
        if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $hashes[$file]){throw ('文件校验失败：'+$file)}
    }
    Add-Type -Path @((Join-Path $PSScriptRoot 'AudioNames.cs'),(Join-Path $PSScriptRoot 'Driver.cs'))
    Save-Defaults ([AudcoreCableTest.Names]::Defaults())
    if(Test-Path -LiteralPath $statePath){$state=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json}
    else {
        if($Action -ne 'Install'){throw '未找到本测试包的设备登记，拒绝操作其他设备'}
        New-Item -ItemType Directory -Path $stateRoot -Force | Out-Null
        $state=[pscustomobject]@{version='1';before=@(Cable-Devices | ForEach-Object {$_.PNPDeviceID});devices=@();complete=$false}
        Cable-Devices | Select-Object Name,PNPDeviceID,HardwareID,ConfigManagerErrorCode | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stateRoot 'before.json') -Encoding UTF8
        Save-State
    }
    if($state.version -ne '1'){throw '登记版本不匹配'}
    if($Action -eq 'Install'){
        if($state.reinstall_pending -eq $true){
            if([int]$state.count -ne $CableCount){throw '上一次重装尚未完成；请使用同一数量继续，或先卸载测试设备'}
            Save-Defaults $state.defaults;$defaultMigration=@($state.migration)
        } else {
            $oldDevices=@(Cable-Devices)
            $defaultMigration=@(New-ReplacementPlan $oldDevices ([AudcoreCableTest.Names]::Inventory()) @($state.devices) $savedDefaults $CableCount)
            $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stateRoot ('before-reinstall-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')) -Encoding UTF8
            $state | Add-Member -NotePropertyName defaults -NotePropertyValue @($savedDefaults) -Force
            $state | Add-Member -NotePropertyName migration -NotePropertyValue $defaultMigration -Force
            $state | Add-Member -NotePropertyName count -NotePropertyValue $CableCount -Force
            $state | Add-Member -NotePropertyName reinstall_pending -NotePropertyValue $true -Force
            $state.complete=$false;Save-State
        }
    }
    $savedDefaults | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $stateRoot 'defaults-before-operation.json') -Encoding UTF8
    if($Action -eq 'Uninstall'){
        $ownedIds=@($state.devices | ForEach-Object {$_.instance})
        $ownedEndpoints=@([AudcoreCableTest.Names]::Inventory() | Where-Object { $_.Owner.StartsWith('{1}.') -and $_.Owner.Substring(4) -in $ownedIds } | ForEach-Object {$_.Id})
        if(@($savedDefaults | Where-Object {$_.Id -in $ownedEndpoints}).Count){throw '测试跳线仍是默认播放、录音或通信设备；请先在 Windows 选择其他默认设备，再卸载，以免删除当前默认设备'}
    }
    if($Action -eq 'Install'){
        Release-CableClients ([string[]]@(Cable-Devices | ForEach-Object {$_.PNPDeviceID}))
        foreach($old in @(Cable-Devices)){
            Note ('正在卸载旧普通 VB-CABLE：'+$old.PNPDeviceID)
            Native @('remove',('@'+$old.PNPDeviceID))
        }
        if(@(Cable-Devices).Count){throw '旧普通 VB-CABLE 尚未全部卸载，停止新安装'}
        $state.devices=@();$state.before=@();Save-State
        for($index=0;$index -lt $CableCount;$index++){
            # A removal veto can leave the unchanged driver loaded after its old
            # registrations disappear. Try new fixed instances with that driver;
            # device error codes and active endpoints, not a cleared reboot flag,
            # determine whether installation is usable without rebooting.
            [AudcoreCableTest.Driver]::Create($index)
            $instance=[AudcoreCableTest.Driver]::Instance($index)
            $state.devices+= [pscustomobject]@{instance=$instance;index=$index;logical_id=('audcore:vb:'+(Cable-Role $index));endpoints=@()}
            Save-State
            if([AudcoreCableTest.Driver]::Bind((Join-Path $PSScriptRoot 'driver\vbMmeCable64_vista.inf'))){$needsRestart=$true}
            Note ('已安装固定实例：'+$instance)
            Restore-Defaults
        }
    }
    $devices=@(Cable-Devices)
    foreach($entry in @($state.devices)){
        if($entry.instance -in @($state.before)){throw '设备登记与安装前设备重叠，停止操作'}
        $device=@($devices | Where-Object {$_.PNPDeviceID -eq $entry.instance})
        if($device.Count -eq 0){if($Action -eq 'Uninstall'){continue};throw ('测试设备缺失：'+$entry.instance)}
        if($Action -eq 'Uninstall'){
            Native @('remove',('@'+$entry.instance))
            continue
        }
        if($device[0].ConfigManagerErrorCode -ne 0){throw ('测试驱动未就绪，设备错误码 '+$device[0].ConfigManagerErrorCode+'；请重启 Windows 后运行“修复更名”，若仍失败则卸载测试设备。本包不会修改系统安全设置。')}
        $adapter=Cable-Adapter ([int]$entry.index)
        if($Action -ne 'Verify'){
            $currentAdapter=Get-PnpDevice -InstanceId $entry.instance -ErrorAction Stop
            $currentDescription=(Get-PnpDeviceProperty -InstanceId $entry.instance -KeyName 'DEVPKEY_Device_DeviceDesc' -ErrorAction Stop).Data
            if($currentAdapter.FriendlyName -ne $adapter -or $currentDescription -ne $adapter){
                [AudcoreCableTest.Names]::Adapter($entry.instance,$adapter)
                Native @('restart',('@'+$entry.instance))
            }
        }
        $endpoints=@()
        for($wait=0;$wait -lt 30;$wait++){
            $endpoints=@([AudcoreCableTest.Names]::Inventory() | Where-Object {$_.Owner -ieq ('{1}.'+$entry.instance)})
            if(@($endpoints | Where-Object Flow -eq 0).Count -eq 1 -and @($endpoints | Where-Object Flow -eq 1).Count -eq 1 -and @($endpoints | Where-Object State -ne 1).Count -eq 0){break}
            Start-Sleep -Milliseconds 500
        }
        if($endpoints.Count -ne 2 -or @($endpoints | Where-Object Flow -eq 0).Count -ne 1){throw ('测试设备端点未完整就绪：'+$entry.instance)}
        $records=@()
        foreach($endpoint in $endpoints){
            $name=Cable-EndpointName ([int]$entry.index) ([int]$endpoint.Flow)
            $suffix='VB-CABLE'
            if($Action -ne 'Verify'){[AudcoreCableTest.Names]::Rename($endpoint.Id,$entry.instance,$name,$suffix,$false)}
            $verified=@([AudcoreCableTest.Names]::Inventory() | Where-Object Id -eq $endpoint.Id)
            $expectedName=$name+' ('+$suffix+')'
            if($verified.Count -ne 1 -or $verified[0].State -ne 1 -or ($Action -eq 'Verify' -and $verified[0].Name -cne $expectedName)){throw ('端点名称或启用状态未通过校验：'+$expectedName)}
            if(@([AudcoreCableTest.Names]::Inventory() | Where-Object {$_.State -eq 1 -and $_.Flow -eq $endpoint.Flow -and $_.Name -eq $expectedName}).Count -gt 1){throw ('存在同方向重名端点：'+$expectedName)}
            $records+=[pscustomobject]@{id=$endpoint.Id;flow=$endpoint.Flow;name=$name;before=$endpoint.Name}
            Note ('端点目标：'+$expectedName)
        }
        $entry.endpoints=$records
        Save-State
        $adapterCheck=Get-PnpDevice -InstanceId $entry.instance -ErrorAction Stop
        if($adapterCheck.FriendlyName -ne $adapter){throw ('适配器名称校验失败：'+$entry.instance)}
    }
    # Reconcile delayed Windows default-device selection once enumeration settles.
    for($settle=0;$settle -lt 6;$settle++){Restore-Defaults; Start-Sleep -Milliseconds 500}
    if($Action -in @('Install','Rename')){
        # EndpointBuilder can refresh the suffix after a device restart. Apply the
        # display override after all restarts and require a stable observed window.
        $stable=0
        for($wait=0;$wait -lt 60 -and $stable -lt 10;$wait++){
            $changed=$false
            foreach($entry in @($state.devices)){
                foreach($record in @($entry.endpoints)){
                    $endpoint=@([AudcoreCableTest.Names]::Inventory() | Where-Object Id -eq $record.id)
                    $expectedName=$record.name+' (VB-CABLE)'
                    if($endpoint.Count -ne 1 -or $endpoint[0].State -ne 1){throw '等待名称稳定时端点不可用'}
                    if($endpoint[0].Name -cne $expectedName){
                        [AudcoreCableTest.Names]::Rename($record.id,$entry.instance,$record.name,'VB-CABLE',$false)
                        $changed=$true
                    }
                    $namedCount=@([AudcoreCableTest.Names]::Inventory() | Where-Object {$_.State -eq 1 -and $_.Flow -eq $record.flow -and $_.Name -eq $expectedName}).Count
                    if($namedCount -gt 1){throw ('存在同方向重名端点：'+$expectedName)}
                    if($namedCount -eq 0){$changed=$true}
                }
            }
            if($changed){$stable=0}else{$stable++}
            Restore-Defaults
            Start-Sleep -Milliseconds 500
        }
        if($stable -lt 10){throw 'Windows 持续回写设备名称，显示后缀尚未稳定'}
    }
    if($Action -eq 'Uninstall'){
        $remaining=@(Cable-Devices | Where-Object {$_.PNPDeviceID -in @($state.devices | ForEach-Object {$_.instance})})
        if($remaining.Count){throw '测试设备仍存在；若提示需要重启，请重启后再次卸载'}
        $state.devices=@();$state.complete=$false;Save-State
        Note '已卸载本测试包登记的设备；保留共享驱动存储，不移除其他软件的驱动包'
    } else {
        $expectedCount=if($Action -eq 'Install'){$CableCount}else{@($state.devices).Count}
        if($expectedCount -lt 1 -or @($state.devices).Count -ne $expectedCount){throw '测试跳线尚未全部安装'}
        Restore-Defaults -RequireResolved
        $state.complete=$true;Save-State
        if($Action -eq 'Install'){$state.reinstall_pending=$false;Save-State}
        $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stateRoot 'bindings.json') -Encoding UTF8
        Note '安装通过：全部端点名称无编号、同方向无重名，固定实例与启用状态已核对。'
    }
    if($needsRestart){Note '新端点已就绪；Windows 仍记录旧设备需要重启清理，可先使用新跳线。本包不会自动重启或清除待重启标记'}
    $exitCode=0
} catch {
    Note ('失败：'+$_.Exception.Message)
    $exitCode=1
} finally {
    try {Restore-Defaults -RequireResolved; if($null -ne $savedDefaults){Note '默认播放、录音与通信设备已核对并保留；旧默认跳线按用途迁移到新实例'}}
    catch {Note ('默认设备恢复失败：'+$_.Exception.Message);$exitCode=1}
    $log | Set-Content -LiteralPath $resultPath -Encoding UTF8
    if(Test-Path -LiteralPath $stateRoot){$log | Set-Content -LiteralPath (Join-Path $stateRoot 'latest-result.txt') -Encoding UTF8}
    if($ownsMutex){$mutex.ReleaseMutex()};$mutex.Dispose()
}
exit $exitCode
